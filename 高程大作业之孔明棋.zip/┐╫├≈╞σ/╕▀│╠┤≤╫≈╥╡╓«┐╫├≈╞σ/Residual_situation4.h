#pragma once
class Residual_situation4
{
public:
    int a = 0;
    void drawBoard();
    void checkMouseClick(int x, int y, int& a);
    bool canMove();
    bool isOnlyOnePiece();
    void undo(int& a);
    void restart();
    void keyboardOperation1(char& ch, int& a);
    void keyboardOperation2(char& ch, int& a);
    void operation_i();
    void operation_j();
    void operation_k();
    void operation_l();
    void restart_the_whole_program();
    void extra_judgement();
};

