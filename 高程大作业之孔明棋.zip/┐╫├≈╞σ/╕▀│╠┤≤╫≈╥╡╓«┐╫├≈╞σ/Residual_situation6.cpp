#include "Residual_situation6.h"
#include <graphics.h>
#include <conio.h>
#include <stack>
#include <string>
using namespace std;

const int BOARD_SIZE6 = 7;
const int CELL_SIZE6 = 100;
const int BOARD_WIDTH6 = BOARD_SIZE6 * CELL_SIZE6;
const int BOARD_HEIGHT6 = BOARD_SIZE6 * CELL_SIZE6;

int history_Residual_situation6[96][2]{ 0 }; // ���ڼ�¼��ʷ����

int board_Residual_situation6[BOARD_SIZE6][BOARD_SIZE6] = {
    { -1, -1, 0, 1, 0, -1, -1 },
    { -1, -1, 0, 1, 0, -1, -1 },
    { 0, 0, 1, 1, 1, 0, 0 },
    { 0, 1, 0, 1, 0, 1, 0 },
    { 0, 0, 1, 0, 1, 0, 0 },
    { -1, -1, 1, 1, 1, -1, -1 },
    { -1, -1, 0, 0, 0, -1, -1 }
};

int initialBoard_Residual_situation6[BOARD_SIZE6][BOARD_SIZE6] = {
    { -1, -1, 0, 1, 0, -1, -1 },
    { -1, -1, 0, 1, 0, -1, -1 },
    { 0, 0, 1, 1, 1, 0, 0 },
    { 0, 1, 0, 1, 0, 1, 0 },
    { 0, 0, 1, 0, 1, 0, 0 },
    { -1, -1, 1, 1, 1, -1, -1 },
    { -1, -1, 0, 0, 0, -1, -1 }
};

// �������̺���
void Residual_situation6::drawBoard() {
    int pieceCount = 0;
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 1 || board_Residual_situation6[i][j] == 2) {
                pieceCount++;
            }
        }
    }

    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            int x = j * CELL_SIZE6;
            int y = i * CELL_SIZE6;

            if (board_Residual_situation6[i][j] != -1) {
                setfillcolor(WHITE);
                fillrectangle(x, y, x + CELL_SIZE6, y + CELL_SIZE6);
                setlinecolor(BLACK);
                rectangle(x, y, x + CELL_SIZE6, y + CELL_SIZE6);

                if (board_Residual_situation6[i][j] == 1) {
                    setfillcolor(BLUE);
                    fillcircle(x + CELL_SIZE6 / 2, y + CELL_SIZE6 / 2, CELL_SIZE6 / 3);
                }
                else if (board_Residual_situation6[i][j] == 2) {
                    setfillcolor(RED);
                    fillcircle(x + CELL_SIZE6 / 2, y + CELL_SIZE6 / 2, CELL_SIZE6 / 3);
                }
                else if (board_Residual_situation6[i][j] == 3) {
                    setfillcolor(RGB(128, 128, 128));
                    fillcircle(x + CELL_SIZE6 / 2, y + CELL_SIZE6 / 2, CELL_SIZE6 / 3);
                }
                else if (board_Residual_situation6[i][j] == 0) {
                    setfillcolor(BLACK);
                    fillcircle(x + CELL_SIZE6 / 2, y + CELL_SIZE6 / 2, CELL_SIZE6 / 3);
                }
            }
        }
    }

    std::string pieceCountStr = "ʣ����������" + to_string(pieceCount);
    settextstyle(40, 0, "��������");
    outtextxy(10, BOARD_HEIGHT6 + 10, pieceCountStr.c_str());
}

void Residual_situation6::checkMouseClick(int x, int y, int& a) {
    int row = y / CELL_SIZE6;
    int col = x / CELL_SIZE6;

    if (row + 2 < BOARD_SIZE6 && board_Residual_situation6[row + 2][col] == 2 && board_Residual_situation6[row + 1][col] == 1 && board_Residual_situation6[row][col] == 3) {
        board_Residual_situation6[row + 2][col] = 0;
        history_Residual_situation6[a][0] = row + 2;
        history_Residual_situation6[a][1] = col;
        a++;
        board_Residual_situation6[row + 1][col] = 0;
        history_Residual_situation6[a][0] = row + 1;
        history_Residual_situation6[a][1] = col;
        a++;
        board_Residual_situation6[row][col] = 1;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE6; i++) {
            for (int j = 0; j < BOARD_SIZE6; j++) {

                if (board_Residual_situation6[i][j] == 3) {
                    board_Residual_situation6[i][j] = 0;
                }
            }
        }
        drawBoard();
    }
    else if (row - 2 >= 0 && board_Residual_situation6[row - 2][col] == 2 && board_Residual_situation6[row - 1][col] == 1 && board_Residual_situation6[row][col] == 3) {
        board_Residual_situation6[row - 2][col] = 0;
        history_Residual_situation6[a][0] = row - 2;
        history_Residual_situation6[a][1] = col;
        a++;
        board_Residual_situation6[row - 1][col] = 0;
        history_Residual_situation6[a][0] = row - 1;
        history_Residual_situation6[a][1] = col;
        a++;
        board_Residual_situation6[row][col] = 1;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE6; i++) {
            for (int j = 0; j < BOARD_SIZE6; j++) {

                if (board_Residual_situation6[i][j] == 3) {
                    board_Residual_situation6[i][j] = 0;
                }
            }
        }
        drawBoard();
    }
    else if (col - 2 >= 0 && board_Residual_situation6[row][col - 2] == 2 && board_Residual_situation6[row][col - 1] == 1 && board_Residual_situation6[row][col] == 3) {
        board_Residual_situation6[row][col - 2] = 0;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col - 2;
        a++;
        board_Residual_situation6[row][col - 1] = 0;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col - 1;
        a++;
        board_Residual_situation6[row][col] = 1;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE6; i++) {
            for (int j = 0; j < BOARD_SIZE6; j++) {

                if (board_Residual_situation6[i][j] == 3) {
                    board_Residual_situation6[i][j] = 0;
                }
            }
        }
        drawBoard();
    }
    else if (col + 2 < BOARD_SIZE6 && board_Residual_situation6[row][col + 2] == 2 && board_Residual_situation6[row][col + 1] == 1 && board_Residual_situation6[row][col] == 3) {
        board_Residual_situation6[row][col + 2] = 0;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col + 2;
        a++;
        board_Residual_situation6[row][col + 1] = 0;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col + 1;
        a++;
        board_Residual_situation6[row][col] = 1;
        history_Residual_situation6[a][0] = row;
        history_Residual_situation6[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE6; i++) {
            for (int j = 0; j < BOARD_SIZE6; j++) {

                if (board_Residual_situation6[i][j] == 3) {
                    board_Residual_situation6[i][j] = 0;
                }
            }
        }
        drawBoard();
    }
    else
    {
        for (int i = 0; i < BOARD_SIZE6; i++) {
            for (int j = 0; j < BOARD_SIZE6; j++) {
                if (board_Residual_situation6[i][j] == 2) {//��ѡ���ĺ�ɫ���Ӹ�Ϊ��ɫ
                    board_Residual_situation6[i][j] = 1;
                }
                if (board_Residual_situation6[i][j] == 3) {
                    board_Residual_situation6[i][j] = 0;
                }
                drawBoard();
            }
        }
        if (row >= 0 && row < BOARD_SIZE6 && col >= 0 && col < BOARD_SIZE6) {
            if (board_Residual_situation6[row][col] == 1) {
                board_Residual_situation6[row][col] = 2;  // ����ɫ���ӱ�Ϊѡ���ĺ�ɫ
                drawBoard();
            }
            if (row + 2 < BOARD_SIZE6 && board_Residual_situation6[row + 1][col] == 1 && board_Residual_situation6[row + 2][col] == 0) {
                board_Residual_situation6[row + 2][col] = 3;
                drawBoard();
            }

            //�õ���ѡ�����·���ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (row - 2 >= 0 && board_Residual_situation6[row - 1][col] == 1 && board_Residual_situation6[row - 2][col] == 0) {
                board_Residual_situation6[row - 2][col] = 3;
                drawBoard();
            }

            //�õ���ѡ������ߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (col - 2 >= 0 && board_Residual_situation6[row][col - 1] == 1 && board_Residual_situation6[row][col - 2] == 0) {
                board_Residual_situation6[row][col - 2] = 3;
                drawBoard();
            }

            //�õ���ѡ�����ұߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (col + 2 < BOARD_SIZE6 && board_Residual_situation6[row][col + 1] == 1 && board_Residual_situation6[row][col + 2] == 0) {
                board_Residual_situation6[row][col + 2] = 3;
                drawBoard();

            }
        }
    }
}

// �ж��Ƿ��п��ƶ�������
bool Residual_situation6::canMove() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 0) {
                if (j > 1 && (board_Residual_situation6[i][j - 1] == 1 || board_Residual_situation6[i][j - 1] == 2) && (board_Residual_situation6[i][j - 2] == 1 || board_Residual_situation6[i][j - 2] == 2)) return true;
                if (j < BOARD_SIZE6 - 2 && (board_Residual_situation6[i][j + 1] == 1 || board_Residual_situation6[i][j + 1] == 2) && (board_Residual_situation6[i][j + 2] == 1 || board_Residual_situation6[i][j + 2] == 2)) return true;
                if (i > 1 && (board_Residual_situation6[i - 1][j] == 1 || board_Residual_situation6[i - 1][j] == 2) && (board_Residual_situation6[i - 2][j] == 1 || board_Residual_situation6[i - 2][j] == 2)) return true;
                if (i < BOARD_SIZE6 - 2 && (board_Residual_situation6[i + 1][j] == 1 || board_Residual_situation6[i + 1][j] == 2) && (board_Residual_situation6[i + 2][j] == 1 || board_Residual_situation6[i + 2][j] == 2)) return true;
            }
            if (board_Residual_situation6[i][j] == 3) {
                if (j > 1 && (board_Residual_situation6[i][j - 1] == 1 || board_Residual_situation6[i][j - 1] == 2) && (board_Residual_situation6[i][j - 2] == 1 || board_Residual_situation6[i][j - 2] == 2)) return true;
                if (j < BOARD_SIZE6 - 2 && (board_Residual_situation6[i][j + 1] == 1 || board_Residual_situation6[i][j + 1] == 2) && (board_Residual_situation6[i][j + 2] == 1 || board_Residual_situation6[i][j + 2] == 2)) return true;
                if (i > 1 && (board_Residual_situation6[i - 1][j] == 1 || board_Residual_situation6[i - 1][j] == 2) && (board_Residual_situation6[i - 2][j] == 1 || board_Residual_situation6[i - 2][j] == 2)) return true;
                if (i < BOARD_SIZE6 - 2 && (board_Residual_situation6[i + 1][j] == 1 || board_Residual_situation6[i + 1][j] == 2) && (board_Residual_situation6[i + 2][j] == 1 || board_Residual_situation6[i + 2][j] == 2)) return true;
            }
        }
    }
    return false;
}

// �ж��Ƿ�ֻʣ��һ������
bool Residual_situation6::isOnlyOnePiece() {
    int count = 0;
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 1) {
                count++;
            }
        }
    }
    return count == 1;
}

// ��������
void Residual_situation6::undo(int& a) {
    if (a >= 3) {
        a--;
        board_Residual_situation6[history_Residual_situation6[a][0]][history_Residual_situation6[a][1]] = 0;

        a--;
        board_Residual_situation6[history_Residual_situation6[a][0]][history_Residual_situation6[a][1]] = 1;

        a--;
        board_Residual_situation6[history_Residual_situation6[a][0]][history_Residual_situation6[a][1]] = 1;

        drawBoard();
    }
}

// ���¿�ʼ
void Residual_situation6::restart() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            board_Residual_situation6[i][j] = initialBoard_Residual_situation6[i][j];
        }
    }
    a = 0; // ������ʷ��¼������
}

// ���̲���
void Residual_situation6::keyboardOperation1(char& ch, int& a) {
    int m = 0;
    int n = 0;
    int bool_num = 0;
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 2) {
                bool_num = 1;
                m = i;
                n = j;
            }
        }
    }
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 2) {
                board_Residual_situation6[i][j] = 1;
            } if (board_Residual_situation6[i][j] == 3) {
                board_Residual_situation6[i][j] = 0;
            }
        }
    }
    if (bool_num == 0) {
        int newRow = (ch >= 'a' && ch <= 'g') ? ch - 'a' : ch - 'A';
        for (int i = 0; i < BOARD_SIZE6; i++) {
            if (board_Residual_situation6[newRow][i] != 0 && board_Residual_situation6[newRow][i] != -1) {
                board_Residual_situation6[newRow][i] = 2; // ��λ��ѡ��
                break;
            }
        }
    }
    else if (bool_num == 1) {
        int newRow = (ch >= 'a' && ch <= 'g') ? ch - 'a' : ch - 'A';
        for (int i = 0; i < BOARD_SIZE6; i++) {
            if (board_Residual_situation6[newRow][i] != 0 && board_Residual_situation6[newRow][i] != -1) {
                board_Residual_situation6[m][n] = 1; // ȡ��ԭ��ѡ��
                board_Residual_situation6[newRow][i] = 2; // ��λ��ѡ��
                break;
            }
        }
    }
}

// ���̲���
void Residual_situation6::keyboardOperation2(char& ch, int& a) {
    int bool_num = 0;
    int m = 0;
    int n = 0;
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 2) {
                bool_num = 1;
                m = i;
                n = j;
            }
        }
    }
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (board_Residual_situation6[i][j] == 2) {
                board_Residual_situation6[i][j] = 1;
            } if (board_Residual_situation6[i][j] == 3) {
                board_Residual_situation6[i][j] = 0;
            }
        }
    }
    if (bool_num == 1) {
        if (m == 2 || m == 3 || m == 4) {
            if (board_Residual_situation6[m][ch - 49] != 0) {
                board_Residual_situation6[m][n] = 1;
                board_Residual_situation6[m][ch - 49] = 2;
            }
        }
        else {
            if (ch == '3' || ch == '4' || ch == '5') {
                if (board_Residual_situation6[m][ch - 49] != 0) {
                    board_Residual_situation6[m][n] = 1;
                    board_Residual_situation6[m][ch - 49] = 2;
                }
            }
        }
    }
}

// ���̿�����������
void Residual_situation6::operation_i() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (i >= 2 && board_Residual_situation6[i][j] == 2 && board_Residual_situation6[i - 1][j] == 1 && board_Residual_situation6[i - 2][j] == 0) {
                board_Residual_situation6[i][j] = 0;
                board_Residual_situation6[i - 1][j] = 0;
                board_Residual_situation6[i - 2][j] = 1;
            }
        }
    }
}

void Residual_situation6::operation_j() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (j >= 2 && board_Residual_situation6[i][j] == 2 && board_Residual_situation6[i][j - 1] == 1 && board_Residual_situation6[i][j - 2] == 0) {
                board_Residual_situation6[i][j] = 0;
                board_Residual_situation6[i][j - 1] = 0;
                board_Residual_situation6[i][j - 2] = 1;
            }
        }
    }
}

void Residual_situation6::operation_k() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (i <= 4 && board_Residual_situation6[i][j] == 2 && board_Residual_situation6[i + 1][j] == 1 && board_Residual_situation6[i + 2][j] == 0) {
                board_Residual_situation6[i][j] = 0;
                board_Residual_situation6[i + 1][j] = 0;
                board_Residual_situation6[i + 2][j] = 1;
            }
        }
    }
}

void Residual_situation6::operation_l() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            if (j <= 4 && board_Residual_situation6[i][j] == 2 && board_Residual_situation6[i][j + 1] == 1 && board_Residual_situation6[i][j + 2] == 0) {
                board_Residual_situation6[i][j] = 0;
                board_Residual_situation6[i][j + 1] = 0;
                board_Residual_situation6[i][j + 2] = 1;
            }
        }
    }
}

void Residual_situation6::restart_the_whole_program() {
    for (int i = 0; i < BOARD_SIZE6; i++) {
        for (int j = 0; j < BOARD_SIZE6; j++) {
            board_Residual_situation6[i][j] = initialBoard_Residual_situation6[i][j];
        }
    }
    a = 0;  // ������ʷ��¼������
}
