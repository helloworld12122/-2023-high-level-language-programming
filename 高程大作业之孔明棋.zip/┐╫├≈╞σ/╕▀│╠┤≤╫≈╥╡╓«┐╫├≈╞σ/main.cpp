#include "Initial_interface.h"
#include "Classic_mode.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <conio.h>
#include <Windows.h>
#include <iomanip>
#include <graphics.h>
#include <limits>
#include "play.h"
using namespace std;
const int BOARD_SIZE = 7;
const int CELL_SIZE = 100;
const int BOARD_WIDTH = BOARD_SIZE * CELL_SIZE;
const int BOARD_HEIGHT = BOARD_SIZE * CELL_SIZE;



int main() {
    SetConsoleTitle(TEXT("������"));
    Play play;
    while (true) {
        char choice = '\0';
        Initial_interface initial_interface;
        initial_interface.print_menu(); // ��ʾ��ʼ����
        choice=_getche();

        switch (choice) {
        case 'a': {
            play.play_classic_mode();
            break;
        }
        case'b': {
            initial_interface.print_second_menu();
            int num = 0;
            num = _getche();
            if (num == '0') {
                play.play_residual_situation1();
                break;
            }
            if (num == '1') {
                play.play_residual_situation2();
                break;
            }
            if (num == '2'){
                play.play_residual_situation3();
                    break;
            }
            if (num == '3') {
                play.play_residual_situation4();
                break;
            }
            if (num == '4') {
                play.play_residual_situation5();
                break;
            }
            if (num == '5') {
                play.play_residual_situation6();
                break;
            }
            if (num == '6') {
                play.play_residual_situation7();
                break;
            }
            if (num == '7') {
                play.play_residual_situation8();
                break;
            }
            if (num == '8') {
                play.play_residual_situation9();
                break;
            }
            if (num == '9') {
                play.play_residual_situation10();
                break;
            }
        }
        case 'c':
            initial_interface.print_help();
            break;
        case 'd':
            initial_interface.print_exit();
            return 0; // �˳�����
        default:
            std::cout << "\n��Ч��ѡ�������ԡ�" << std::endl;
            break;
        }
    }

    return 0;
}