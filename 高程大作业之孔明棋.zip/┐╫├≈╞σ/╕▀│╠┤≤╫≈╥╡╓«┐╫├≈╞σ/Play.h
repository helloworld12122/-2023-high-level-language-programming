#pragma once
class Play
{public:
	void play_classic_mode();
	void play_residual_situation1();
	void play_residual_situation2();
	void play_residual_situation3();
	void play_residual_situation4();
	void play_residual_situation5();
	void play_residual_situation6();
	void play_residual_situation7();
	void play_residual_situation8();
	void play_residual_situation9();
	void play_residual_situation10();
};

