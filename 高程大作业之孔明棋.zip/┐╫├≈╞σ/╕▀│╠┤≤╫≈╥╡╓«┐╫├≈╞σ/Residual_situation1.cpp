#include "Residual_situation1.h"
#include <graphics.h>
#include <conio.h>
#include <stack>
#include<string>
using namespace std;
// �������̵Ĵ�С��ÿ�����ӵĴ�С
const int BOARD_SIZE = 7;
const int CELL_SIZE = 100;
const int BOARD_WIDTH = BOARD_SIZE * CELL_SIZE;
const int BOARD_HEIGHT = BOARD_SIZE * CELL_SIZE;

int history_Residual_situation1[96][2]{ 0 };//���ڼ�¼��ʷ����

// ����������̲��֣�2��ʾ��ѡ�е����ӣ��죩��1��ʾ�����ӣ�������0��ʾ�����ӣ��ڣ���-1��ʾ��Чλ��(�ڣ���
int board_Residual_situation1[BOARD_SIZE][BOARD_SIZE] = {
{  -1, - 1 ,0 ,0 ,0 ,- 1 ,- 1},
{-1, - 1 ,0 ,1, 0 ,- 1, - 1},
{0 ,0 ,1 ,1 ,1 ,0 ,0},
{0, 0, 0 ,1, 0, 0, 0},
{0, 0, 0, 1, 0, 0 ,0},
{-1 ,- 1, 0 ,0 ,0 ,- 1 ,- 1},
{-1 ,- 1, 0 ,0, 0, - 1 ,- 1}

};

int initialBoard_Residual_situation1[BOARD_SIZE][BOARD_SIZE] = {
{  -1, -1 ,0 ,0 ,0 ,-1 ,-1},
{-1, -1 ,0 ,1, 0 ,-1, -1},
{0 ,0 ,1 ,1 ,1 ,0 ,0},
{0, 0, 0 ,1, 0, 0, 0},
{0, 0, 0, 1, 0, 0 ,0},
{-1 ,-1, 0 ,0 ,0 ,-1 ,-1},
{-1 ,-1, 0 ,0, 0, -1 ,-1}
};








// �������̺���
void Residual_situation1::drawBoard() {
    // ͳ��ʣ����������
    int pieceCount = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 1 || board_Residual_situation1[i][j] == 2) {
                pieceCount++;
            }
        }
    }

    // ��������
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            // ����ÿ�����ӵ����Ͻ�����
            int x = j * CELL_SIZE;
            int y = i * CELL_SIZE;

            if (board_Residual_situation1[i][j] != -1) {
                setfillcolor(WHITE);
                fillrectangle(x, y, x + CELL_SIZE, y + CELL_SIZE);
                setlinecolor(BLACK);
                rectangle(x, y, x + CELL_SIZE, y + CELL_SIZE);

                if (board_Residual_situation1[i][j] == 1) {
                    setfillcolor(BLUE);
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, CELL_SIZE / 3);
                }
                else if (board_Residual_situation1[i][j] == 2) {
                    setfillcolor(RED);
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, CELL_SIZE / 3);
                }
                else if (board_Residual_situation1[i][j] == 3) {
                    setfillcolor(RGB(128, 128, 128));
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, CELL_SIZE / 3);
                }
                else if (board_Residual_situation1[i][j] == 0) {
                    setfillcolor(BLACK);
                    fillcircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, CELL_SIZE / 3);
                }
            }
        }
    }

    // ��ʾʣ����������
    std::string pieceCountStr = "ʣ����������" + to_string(pieceCount);
    settextstyle(40, 0, "��������");
    /*  settextcolor(FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_INTENSITY);*/
      // ���ı���ʾ�������·�
    outtextxy(10, BOARD_HEIGHT + 10, pieceCountStr.c_str());
}

//�����겢���к���
void Residual_situation1::checkMouseClick(int x, int y, int& a) {
    int row = y / CELL_SIZE;
    int col = x / CELL_SIZE;

    //�����߼�
    //�õ���ѡ�����Ϸ���ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
    if (row + 2 < BOARD_SIZE && board_Residual_situation1[row + 2][col] == 2 && board_Residual_situation1[row + 1][col] == 1 && board_Residual_situation1[row][col] == 3) {
        board_Residual_situation1[row + 2][col] = 0;//��ʼ��
        history_Residual_situation1[a][0] = row + 2;
        history_Residual_situation1[a][1] = col;
        a++;
        board_Residual_situation1[row + 1][col] = 0;//������
        history_Residual_situation1[a][0] = row + 1;
        history_Residual_situation1[a][1] = col;
        a++;
        board_Residual_situation1[row][col] = 1;//�յ�
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {

                if (board_Residual_situation1[i][j] == 3) {
                    board_Residual_situation1[i][j] = 0;
                }
            }
        }
        
        drawBoard();
    }

    //�õ���ѡ�����·���ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
    else if (row - 2 >= 0 && board_Residual_situation1[row - 2][col] == 2 && board_Residual_situation1[row - 1][col] == 1 && board_Residual_situation1[row][col] == 3) {
        board_Residual_situation1[row - 2][col] = 0;//��ʼ��
        history_Residual_situation1[a][0] = row - 2;
        history_Residual_situation1[a][1] = col;
        a++;
        board_Residual_situation1[row - 1][col] = 0;//������
        history_Residual_situation1[a][0] = row - 1;
        history_Residual_situation1[a][1] = col;
        a++;
        board_Residual_situation1[row][col] = 1;//�յ�
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {

                if (board_Residual_situation1[i][j] == 3) {
                    board_Residual_situation1[i][j] = 0;
                }
            }
        }
        drawBoard();
    }

    //�õ���ѡ������ߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
    else if (col - 2 >= 0 && board_Residual_situation1[row][col - 2] == 2 && board_Residual_situation1[row][col - 1] == 1 && board_Residual_situation1[row][col] == 3) {
        board_Residual_situation1[row][col - 2] = 0;//��ʼ��
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col - 2;
        a++;
        board_Residual_situation1[row][col - 1] = 0;//������
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col - 1;
        a++;
        board_Residual_situation1[row][col] = 1;//�յ�
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {

                if (board_Residual_situation1[i][j] == 3) {
                    board_Residual_situation1[i][j] = 0;
                }
            }
        }
        drawBoard();
    }

    //�õ���ѡ�����ұߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
    else if (col + 2 < BOARD_SIZE && board_Residual_situation1[row][col + 2] == 2 && board_Residual_situation1[row][col + 1] == 1 && board_Residual_situation1[row][col] == 3) {
        board_Residual_situation1[row][col + 2] = 0;//��ʼ��
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col + 2;
        a++;
        board_Residual_situation1[row][col + 1] = 0;//������
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col + 1;
        a++;
        board_Residual_situation1[row][col] = 1;//�յ�
        history_Residual_situation1[a][0] = row;
        history_Residual_situation1[a][1] = col;
        a++;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {

                if (board_Residual_situation1[i][j] == 3) {
                    board_Residual_situation1[i][j] = 0;
                }
            }
        }
        drawBoard();
    }
    else
    {
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (board_Residual_situation1[i][j] == 2) {//��ѡ���ĺ�ɫ���Ӹ�Ϊ��ɫ
                    board_Residual_situation1[i][j] = 1;
                }
                if (board_Residual_situation1[i][j] == 3) {
                    board_Residual_situation1[i][j] = 0;
                }
                drawBoard();
            }
        }
        if (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE) {
            if (board_Residual_situation1[row][col] == 1) {
                board_Residual_situation1[row][col] = 2;  // ����ɫ���ӱ�Ϊѡ���ĺ�ɫ
                drawBoard();
            }
            if (row + 2 < BOARD_SIZE && board_Residual_situation1[row + 1][col] == 1 && board_Residual_situation1[row + 2][col] == 0) {
                board_Residual_situation1[row + 2][col] = 3;
                drawBoard();
            }

            //�õ���ѡ�����·���ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (row - 2 >= 0 && board_Residual_situation1[row - 1][col] == 1 && board_Residual_situation1[row - 2][col] == 0) {
                board_Residual_situation1[row - 2][col] = 3;
                drawBoard();
            }

            //�õ���ѡ������ߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (col - 2 >= 0 && board_Residual_situation1[row][col - 1] == 1 && board_Residual_situation1[row][col - 2] == 0) {
                board_Residual_situation1[row][col - 2] = 3;
                drawBoard();
            }

            //�õ���ѡ�����ұߣ�ͬʱ��ʷ��¼�����μ��³�ʼ�㣬�����㣬�յ�����
            if (col + 2 < BOARD_SIZE && board_Residual_situation1[row][col + 1] == 1 && board_Residual_situation1[row][col + 2] == 0) {
                board_Residual_situation1[row][col + 2] = 3;
                drawBoard();

            }
        }
    }
}
// �ж��Ƿ��п��ƶ�������
bool Residual_situation1::canMove() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 0) {
                // ���ˮƽ�ʹ�ֱ�����Ƿ����������������Ӻ�һ����λ
                if (j > 1 && (board_Residual_situation1[i][j - 1] == 1 or board_Residual_situation1[i][j - 1] == 2) && (board_Residual_situation1[i][j - 2] == 1 or board_Residual_situation1[i][j - 2] == 2)) return true;
                if (j < BOARD_SIZE - 2 && (board_Residual_situation1[i][j + 1] == 1 or board_Residual_situation1[i][j + 1] == 2) && (board_Residual_situation1[i][j + 2] == 1 or board_Residual_situation1[i][j + 2] == 2)) return true;
                if (i > 1 && (board_Residual_situation1[i - 1][j] == 1 or board_Residual_situation1[i - 1][j] == 2) && (board_Residual_situation1[i - 2][j] == 1 or board_Residual_situation1[i - 2][j] == 2)) return true;
                if (i < BOARD_SIZE - 2 && (board_Residual_situation1[i + 1][j] == 1 or board_Residual_situation1[i + 1][j] == 2) && (board_Residual_situation1[i + 2][j] == 1 or board_Residual_situation1[i + 2][j] == 2)) return true;
            }
            else if (board_Residual_situation1[i][j] == 3) {
                // ���ˮƽ�ʹ�ֱ�����Ƿ����������������Ӻ�һ����λ
                if (j > 1 && (board_Residual_situation1[i][j - 1] == 1 or board_Residual_situation1[i][j - 1] == 2) && (board_Residual_situation1[i][j - 2] == 1 or board_Residual_situation1[i][j - 2] == 2)) return true;
                if (j < BOARD_SIZE - 2 && (board_Residual_situation1[i][j + 1] == 1 or board_Residual_situation1[i][j + 1] == 2) && (board_Residual_situation1[i][j + 2] == 1 or board_Residual_situation1[i][j + 2] == 2)) return true;
                if (i > 1 && (board_Residual_situation1[i - 1][j] == 1 or board_Residual_situation1[i - 1][j] == 2) && (board_Residual_situation1[i - 2][j] == 1 or board_Residual_situation1[i - 2][j] == 2)) return true;
                if (i < BOARD_SIZE - 2 && (board_Residual_situation1[i + 1][j] == 1 or board_Residual_situation1[i + 1][j] == 2) && (board_Residual_situation1[i + 2][j] == 1 or board_Residual_situation1[i + 2][j] == 2)) return true;
            }
        }
    }
    return false;
}
// �ж��Ƿ�ֻʣ��һ������
bool Residual_situation1::isOnlyOnePiece() {
    int count = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 1) {
                count++;
            }
        }
    }
    return count == 1;
}
//��������
void Residual_situation1::undo(int& a) {
    if (a >= 3) { // ȷ�����㹻����ʷ��¼������
        a--; // �����յ�
        board_Residual_situation1[history_Residual_situation1[a][0]][history_Residual_situation1[a][1]] = 0; // ���յ㳷��Ϊ0

        a--; // ����������
        board_Residual_situation1[history_Residual_situation1[a][0]][history_Residual_situation1[a][1]] = 1; // �������㲹��������

        a--; // ������ʼ��
        board_Residual_situation1[history_Residual_situation1[a][0]][history_Residual_situation1[a][1]] = 1; // ����ʼ�㲹��������

        drawBoard(); // ��������
    }
}
//���¿�ʼ
void Residual_situation1::restart() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            history_Residual_situation1[i][j] = initialBoard_Residual_situation1[i][j];
        }
    }
    drawBoard();
}
//���̲���
//a-g��A-Gȷ����
void Residual_situation1::keyboardOperation1(char& ch, int& a) {
    int m = 0; // ��¼��λ��
    int n = 0; // ��¼��λ��
    int bool_num = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 2) {
                bool_num = 1;
                m = i;
                n = j;
            }
        }
    }
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 2) {
                board_Residual_situation1[i][j] = 1;
            } if (board_Residual_situation1[i][j] == 3) {
                board_Residual_situation1[i][j] = 0;
            }
        }
    }
    if (bool_num == 0) {
        int newRow = (ch >= 'a' && ch <= 'g') ? ch - 'a' : ch - 'A';
        for (int i = 0; i < BOARD_SIZE; i++)
        {
            if (board_Residual_situation1[newRow][i] != 0 && board_Residual_situation1[newRow][i] != -1) {
                board_Residual_situation1[newRow][i] = 2; // ��λ��ѡ��
                break;
            }
        }
    }
    else if (bool_num == 1) {
        int newRow = (ch >= 'a' && ch <= 'g') ? ch - 'a' : ch - 'A';
        for (int i = 0; i < BOARD_SIZE; i++)
        {
            if (board_Residual_situation1[newRow][i] != 0 && board_Residual_situation1[newRow][i] != -1) {
                board_Residual_situation1[m][n] = 1; // ȡ��ԭ��ѡ��
                board_Residual_situation1[newRow][i] = 2; // ��λ��ѡ��
                break;
            }
        }
    }



}
//1-7ȷ����
void Residual_situation1::keyboardOperation2(char& ch, int& a) {

    int bool_num = 0;
    int m = 0;//��¼��λ��
    int n = 0;//��¼��λ��
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 2) {
                bool_num = 1;
                m = i;
                n = j;
            }
        }
    }
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board_Residual_situation1[i][j] == 2) {
                board_Residual_situation1[i][j] = 1;
            } if (board_Residual_situation1[i][j] == 3) {
                board_Residual_situation1[i][j] = 0;
            }
        }
    }
    if (bool_num == 1) {
        if (m == 2 or m == 3 or m == 4) {
            if (board_Residual_situation1[m][ch - 49] != 0) {
                board_Residual_situation1[m][n] = 1;
                board_Residual_situation1[m][ch - 49] = 2;
            }
        }
        else {
            if (ch == '3' or ch == '4' or ch == '5') {
                if (board_Residual_situation1[m][ch - 49] != 0) {
                    board_Residual_situation1[m][n] = 1;
                    board_Residual_situation1[m][ch - 49] = 2;
                }
            }
        }
    }
}
//���̿�����������
//��
void Residual_situation1::operation_i() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (i >= 2 && board_Residual_situation1[i][j] == 2 && board_Residual_situation1[i - 1][j] == 1 && board_Residual_situation1[i - 2][j] == 0) {
                board_Residual_situation1[i][j] = 0;
                board_Residual_situation1[i - 1][j] = 0;
                board_Residual_situation1[i - 2][j] = 1;
            }
        }
    }
}
//��
void Residual_situation1::operation_j() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (j >= 2 && board_Residual_situation1[i][j] == 2 && board_Residual_situation1[i][j - 1] == 1 && board_Residual_situation1[i][j - 2] == 0) {
                board_Residual_situation1[i][j] = 0;
                board_Residual_situation1[i][j - 1] = 0;
                board_Residual_situation1[i][j - 2] = 1;
            }
        }
    }
}
//��
void Residual_situation1::operation_k() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (i <= 4 && board_Residual_situation1[i][j] == 2 && board_Residual_situation1[i + 1][j] == 1 && board_Residual_situation1[i + 2][j] == 0) {
                board_Residual_situation1[i][j] = 0;
                board_Residual_situation1[i + 1][j] = 0;
                board_Residual_situation1[i + 2][j] = 1;
            }
        }
    }
}
//��
void Residual_situation1::operation_l() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (j <= 4 && board_Residual_situation1[i][j] == 2 && board_Residual_situation1[i][j + 1] == 1 && board_Residual_situation1[i][j + 2] == 0) {
                board_Residual_situation1[i][j] = 0;
                board_Residual_situation1[i][j + 1] = 0;
                board_Residual_situation1[i][j + 2] = 1;
            }
        }
    }
}

void Residual_situation1::restart_the_whole_program() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            board_Residual_situation1[i][j] = initialBoard_Residual_situation1[i][j];
        }
    }
    a = 0;  // ������ʷ��¼������
}

