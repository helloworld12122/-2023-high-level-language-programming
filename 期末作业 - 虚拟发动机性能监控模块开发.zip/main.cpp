﻿// EngineSimulation.cpp
#define _CRT_SECURE_NO_WARNINGS  // 禁用安全函数警告

#include <easyx.h>
#include <graphics.h>
#include <conio.h>
#include <ctime>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <map>
#include <algorithm>

// 定义常量
const int WINDOW_WIDTH = 940;
const int WINDOW_HEIGHT = 840;
const double ENGINE_RATED_RPM = 40000;  // 额定转速
const double ENGINE_RATED_TEMP = 1000;  // 额定温度
const double minRPM = 0;//最小有效转速
const double maxRPM = 50000;//最大有效转速
const double maxRPMLevel2 = 48000;
const double maxRPMLevel1 = 42000;
const double minEGT = -5;//最小有效温度
const double maxEGT = 1200;//最小有效温度
const double maxTempLevel1 = 850;
const double maxTempLevel2 = 1000;
const double maxTempLevel3 = 950;
const double maxTempLevel4 = 1100;
const double minFuelLevel = 1000;  // 假定燃油最低余量为 10%
const double maxFuelLevel = 20000; // 假定燃油最大余量为 100%
const double maxFuelFlow = 50;   // 假定最大燃油流速为 50 单位
bool rpm1_left_error_emerged = false;
bool rpm1_right_error_emerged = false;
bool egt1_left_error_emerged = false;
bool egt1_right_error_emerged = false;
bool rpm2_left_error_emerged = false;
bool rpm2_right_error_emerged = false;
bool egt2_left_error_emerged = false;
bool egt2_right_error_emerged = false;
bool fuel_quantity_error_emerged = false;
bool fuel_consumption_error_emerged = false;

// 设置转速和温度的合理范围






// 添加 M_PI 的定义
#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795028841
#endif
void removeDuplicateExceptions();
void sortExceptions();

// 定义颜色常量
const COLORREF ORANGE_COLOR = RGB(255, 165, 0);
const COLORREF AMBER_COLOR = RGB(255, 191, 0);
const COLORREF RED_COLOR = RGB(255, 0, 0);

// 定义枚举类型
enum EngineState {
    OFF,
    STARTING,
    RUNNING,
    STOPPING
};

enum SensorStatus {
    NORMAL,
    WARNING,
    ALERT,
    INVALID
};

// 定义结构体
struct SensorData {
    double rpm1_left;
    double rpm1_right;
    double egt1_left;
    double egt1_right;
    double rpm2_left;
    double rpm2_right;
    double egt2_left;
    double egt2_right;
    double fuel_quantity;
    double fuel_consumption;
};

// 定义异常类型
enum ExceptionType {
    N1LFail ,N1RFail, EGT1LFail, EGT1RFail,
    N2LFail, N2RFail, EGT2LFail, EGT2RFail,
    N1Fail, EGT1Fail, N2Fail, EGT2Fail,
    NSFail,EGTSFail,
    LowFuel, FuelSFail, OverFF,
    OverSpd1, OverSpd2,
    OverTemp1, OverTemp2, OverTemp3, OverTemp4
};

// 定义异常信息结构体
struct ExceptionInfo {
    ExceptionType type;
    std::wstring message;
    COLORREF color;
    double triggerTime;
};

// 全局变量
EngineState currentState = OFF;
double elapsedTime = 0.0; // 秒
double errorTime = 0.0; // 秒
double deltaTime = 0.005; // 5毫秒
SensorData data;

// 文件输出
std::ofstream dataFile;
std::ofstream logFile;

// 按钮区域
struct Button {
    int x, y, width, height;
    std::wstring label;
    COLORREF button_color;

} startButton, stopButton, increaseThrustButton, decreaseThrustButton,createErrorButton;

// 异常管理
std::vector<ExceptionInfo> activeExceptions;
std::map<ExceptionType, double> exceptionLastLoggedTime;


// 初始化按钮
void initializeButtons() {
    startButton = { 10, 690, 100, 50, L"Start",GREEN };
    stopButton = { 10, 770, 100, 50, L"Stop",RED };
    increaseThrustButton = { 130, 690, 70, 50, L"▲",BLUE };
    decreaseThrustButton = { 130, 770, 70, 50, L"▼",BLUE };
    createErrorButton = { 220,730,90,50,L"Error",ORANGE_COLOR };
}

void SleepMicroseconds(long long microseconds) {
    LARGE_INTEGER frequency;
    LARGE_INTEGER start, now;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&start);
    now = start;
    while ((now.QuadPart - start.QuadPart) < microseconds * frequency.QuadPart / 1000000) {
        QueryPerformanceCounter(&now);
    }
}


// 绘制按钮
void drawButton(const Button& btn) {
        setfillcolor(btn.button_color);
        setbkcolor(btn.button_color);
        setlinecolor(btn.button_color);
        settextcolor(WHITE);   
    fillrectangle(btn.x, btn.y, btn.x + btn.width, btn.y + btn.height);
    
    rectangle(btn.x, btn.y, btn.x + btn.width, btn.y + btn.height);
    
    settextstyle(40, 0, L"Verdana");

    // 计算文字宽度以居中显示
    int textWidth = textwidth(btn.label.c_str());
    int textHeight = textheight(btn.label.c_str());
    outtextxy(btn.x + (btn.width - textWidth) / 2, btn.y + (btn.height - textHeight) / 2, btn.label.c_str());

    //恢复初始
    setbkcolor(TRANSPARENT);
    setlinecolor(WHITE);
}

// 绘制仪表盘指示
void drawDial(int x, int y, double value, double max_value, const std::wstring& label, COLORREF color, bool isRPM = true) {
    // 设置背景弧线
    double unit_radius = 0;
    double clampedValue = 0;
    double truevalue = 0;
    double angle = 0;
    if(isRPM)
    {
        unit_radius = (2 * M_PI - 5 * M_PI / 6) / 125;
        // 绘制背景弧线，0 到 210°的圆弧
        setcolor(RED);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6, 5 * M_PI / 6 + 5 * unit_radius); // 起始角度 150°，终止角度 360°
        setcolor(AMBER_COLOR);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6 + 5 * unit_radius, 5 * M_PI / 6 + 20 * unit_radius); // 起始角度 150°，终止角度 360°
        setcolor(WHITE);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6 + 20 * unit_radius, 5 * M_PI / 6 + 125 * unit_radius); // 起始角度 150°，终止角度 360°
        // 绘制背景矩形
        rectangle(x, y - 40, x + 70, y);

        // 计算指针角度
        // 假设0%对应5π/6（即150度），100%对应2π（即360度），并且旋转方向顺时针
        clampedValue = max(0.0, min(value / (max_value * 1.25), 1.25));  // 0到1的映射
        truevalue = max(0.0, min(value / max_value, 1.25));
        // 线性映射，0% -> 5π/6度，100% -> 2π度
       angle = 2.0 * M_PI - ((2.0 * M_PI - 5.0 * M_PI / 6.0) * clampedValue);

        // 绘制填充区域
        if (value > 0)
        {
            setfillcolor(color);
            fillpie(x - 60, y - 60, x + 60, y + 60, angle, 2 * M_PI);
        }
    }
    if (!isRPM)
    {
        unit_radius = (2 * M_PI - 5 * M_PI / 6) / 1205;
        // 绘制背景弧线，0 到 210°的圆弧
        setcolor(RED);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6, 5 * M_PI / 6 + 100 * unit_radius); //1105~1205
        setcolor(AMBER_COLOR);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6 + 100 * unit_radius, 5 * M_PI / 6 + 355 * unit_radius); //955~1105     
        setcolor(WHITE);
        arc(x - 60, y - 60, x + 60, y + 60, 5 * M_PI / 6 + 355 * unit_radius, 5 * M_PI / 6 + 1205 * unit_radius); // 0~955
        // 绘制背景矩形
        rectangle(x, y - 40, x + 70, y);

        // 计算指针角度
        // 假设0%对应5π/6（即150度），100%对应2π（即360度），并且旋转方向顺时针
        clampedValue = max(0.0, min((value+5) / (max_value * 1.205), 1.205));  // 0到1的映射
        truevalue = max(0.0, min((value + 5) / max_value, 1.205));
        // 线性映射，0% -> 5π/6度，100% -> 2π度
        angle = 2.0 * M_PI - ((2.0 * M_PI - 5.0 * M_PI / 6.0) * clampedValue);

        // 绘制填充区域
        if (value + 5 > 0)
        {
            setfillcolor(color);
            fillpie(x - 60, y - 60, x + 60, y + 60, angle, 2 * M_PI);
        }
    }


    // 绘制标签
    settextcolor(WHITE);
    settextstyle(16, 0, L"Verdana");
    outtextxy(x - 20, y + 70, label.c_str());

    // 显示数值，并将其放置在长方形的中心
    std::wstring displayStr = isRPM ? ((value >= minRPM && value <= maxRPM) ? std::to_wstring(truevalue * 100).substr(0, 6) + L" %" : L"------") : ((value >= minEGT && value <= maxEGT) ? std::to_wstring(value).substr(0, 6) + L" ℃":L"------");

    // 调整显示数值的位置到长方形的中心
    int textWidth = textwidth(displayStr.c_str());
    int textHeight = textheight(displayStr.c_str());

    // 计算文本的显示位置，使其居中
    int textX = x + (70 - textWidth) / 2;  // 长方形宽度70，文本居中
    int textY = y - 20 - (textHeight / 2); // 长方形的垂直中心，y-20是长方形的中点

    // 显示数值
    outtextxy(textX, textY, displayStr.c_str());
}

// 绘制燃油流速
void drawFuelFlow( double fuel_consumption, double fuel_quantity) {
    // 燃料与流量显示框
    outtextxy(20, 595, L"Fuel Flow:");
    rectangle(160, 592, 300, 628);
    outtextxy(20, 640, L"Total Fuel:");
    rectangle(160, 637, 300, 673);

    // 绘制文字
    settextcolor(WHITE);
    settextstyle(18, 0, L"Verdana");

    // 将浮点数转换为宽字符字符串
    std::wstring fuelConsumptionStr = fuel_consumption >=0&& fuel_consumption <=50?std::to_wstring(fuel_consumption):L"------";
    std::wstring fuelQuantityStr = fuel_quantity>=0&& fuel_quantity<=20000 ?std::to_wstring(fuel_quantity):L"Error";
  
 if (fuel_consumption >= 0 && fuel_consumption <= 50) {
        settextcolor(WHITE);
    }
    else
    {
        settextcolor(AMBER_COLOR);
    }
    // 绘制 fuel_consumption 到第一个框中
    outtextxy(170, 600, fuelConsumptionStr.c_str());

    // 绘制 fuel_quantity 到第二个框中

    settextcolor(WHITE);
    if (fuel_quantity >= 0 && fuel_quantity < 1000) {
        settextcolor(AMBER_COLOR);
    }
    else if (fuel_quantity < 0) {
        settextcolor(RED);
    }
    outtextxy(170, 645, fuelQuantityStr.c_str());
    settextcolor(WHITE);
}

void draw_warning_light(int left, int top, int right, int bottom, const wchar_t* text, COLORREF color) {
    setfillcolor(color);  // 设置警告灯的颜色
    fillrectangle(left, top, right, bottom);
    setlinecolor(WHITE);  // 设置边框颜色
    setbkcolor(color);  // 设置背景为透明
    rectangle(left, top, right, bottom);  // 绘制警告灯外框
    if (color == WHITE) {
        settextcolor(BLACK);
    }
    else
    {
        settextcolor(WHITE);  // 设置文字颜色为白色
    }
    int text_width = textwidth(text);  // 获取文本宽度
    int text_height = textheight(text);  // 获取文本高度
    outtextxy((left + right) / 2 - text_width / 2, (top + bottom) / 2 - text_height / 2, text);  // 绘制文本
    setbkcolor(TRANSPARENT);  // 设置背景为透明
}

int warning_color[26] = { BLACK };

// 绘制状态显示框
void drawStatus(int x, int y, const std::wstring& status) {
    // 警告灯布局
    const wchar_t* warning_texts[26] = {
        L"Start", L"Run",L"Stop",
        L"N1LFail", L"N1RFail",L"EGT1LFail", L"EGT1RFail",
        L"N2LFail", L"N2RFail",L"EGT2LFail", L"EGT2RFail",
        L"N1Fail", L"EGT1Fail",L"N2Fail", L"EGT2Fail",
        L"NSFail", L"EGTSFail",L"LowFuel", L"FuelSFail",
        L"OverFF",L"OverSpd1", L"OverSpd2",
        L"OverTemp1", L"OverTemp2", L"OverTemp3", L"OverTemp4"
    };

    int warning_positions[26][4] = {
        {335, 20, 465, 60}, {475, 20, 605, 60},{615,20,745,60},
        {335, 70, 465, 110}, {475, 70, 605, 110},{615, 70, 745, 110}, {755, 70, 885, 110},
        {335, 120, 465, 160}, {475, 120, 605, 160},{615, 120, 745, 160}, {755, 120, 885, 160},
        {335, 170, 465, 210}, {475, 170, 605, 210},{615, 170, 745, 210}, {755, 170, 885, 210},
        {335, 220, 465, 260}, {475, 220, 605, 260},{615, 220, 745, 260}, {755, 220, 885, 260},
        {335, 270, 465, 310},{475, 270, 605, 310},{615, 270, 745, 310},   
        {335, 320, 475, 360},{485, 320, 625, 360},{635, 320, 775, 360},{785, 320, 925, 360}
    };


    settextstyle(28, 0, L"Verdana");
    for (int i = 0; i < 26; ++i) {
        draw_warning_light(warning_positions[i][0], warning_positions[i][1],
            warning_positions[i][2], warning_positions[i][3],
            warning_texts[i], warning_color[i]);
    }
    //边框
    setcolor(CYAN);
    line(320, 0, 320, 840);
    line(320, 370, 940, 370);

    line(0, 685, 320, 685);
    line(120, 685, 120, 840);
    line(210, 685, 210, 840);
    setcolor(WHITE);
}

// 绘制异常警示
void drawAlerts() {
    roundrect(330, 380, 930, 820, 20, 20);
    int alertY = 390;
    for (const auto& ex : activeExceptions) {
        // 绘制警示文字
        settextcolor(ex.color);
        settextstyle(20, 0, L"Verdana");
        outtextxy(340, alertY, ex.message.c_str());
        alertY += 30; // 下移以显示多个警示
    }
}

// 检测按钮点击
bool isButtonClicked(const Button& btn, int mx, int my) {
    return (mx >= btn.x && mx <= btn.x + btn.width &&
        my >= btn.y && my <= btn.y + btn.height);
}

// 记录数据到CSV
void logData(const SensorData& d) {
    dataFile << elapsedTime << ","
        << d.rpm1_left << ',' 
        << d.rpm1_right << ',' 
        << d.egt1_left << ',' 
        << d.egt1_right << ',' 
        << d.rpm2_left << ',' 
        << d.rpm2_right << ',' 
        << d.egt2_left << ',' 
        << d.egt2_right << ',' 
        << d.fuel_consumption << ',' 
        << d.fuel_quantity << "\n";
}

// 记录异常到日志
void logAnomaly(const ExceptionInfo& ex) {
    logFile << currentState <<"-"<< elapsedTime << " - " << std::string(ex.message.begin(), ex.message.end()) << "\n";
}

// 定义数据状态标志（避免重复修改）
bool isFuelConsumptionInvalid = false;
bool isFuelQuantityInvalid = false;
bool isRpm1LeftInvalid = false;
bool isRpm1RightInvalid = false;
bool isEgt1LeftInvalid = false;
bool isEgt1RightInvalid = false;
bool isRpm2LeftInvalid = false;
bool isRpm2RightInvalid = false;
bool isEgt2LeftInvalid = false;
bool isEgt2RightInvalid = false;

double change_rpm() {
    int randChoice = std::rand() % 3;
    double num;
    switch (randChoice) {
    case 0:num = -1; break;
    case 1:num = 45000; break;
    case 2:num = 49000; break;
    }
    return num;
}

double change_egt_at_start_stage() {
    int randChoice = std::rand() % 3;
    double num;
    switch (randChoice) {
    case 0:num = -1; break;
    case 1:num = 925; break;
    case 2:num = 1075; break;
    }
    return num;
}

double change_egt_at_run_stage() {
    int randChoice = std::rand() % 3;
    double num;
    switch (randChoice) {
    case 0:num = -1; break;
    case 1:num = 1025; break;
    case 2:num = 1150; break;
    }
    return num;
}

void simulateExceptions() {
    // 随机选择数据并修改为无效值或超限值
    int randChoice = std::rand() % 16;  // 生成0到15的随机数，表示16种数据类型

    if (currentState == STARTING) {
        switch (randChoice) {
        case 0: // 修改燃油流速
            if (!isFuelConsumptionInvalid) {
                data.fuel_consumption = 51; // 随机选择无效值或超限值
                isFuelConsumptionInvalid = true;
            }
            break;
        case 1: // 修改燃油余量
            if (!isFuelQuantityInvalid) {
                data.fuel_quantity = (std::rand() % 2 == 0) ? -1 : 999; // 随机选择无效值或超限值
                isFuelQuantityInvalid = true;
            }
            break;
        case 2: // 修改发动机转速传感器1
            if (!isRpm1LeftInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
            }
            break;
        case 3: // 修改发动机转速传感器2
            if (!isRpm1RightInvalid) {
                data.rpm1_right = change_rpm(); // 修改为此格式
                isRpm1RightInvalid = true;
            }
            break;
        case 4: // 修改EGT传感器1
            if (!isEgt1LeftInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
            }
            break;
        case 5: // 修改EGT传感器2
            if (!isEgt1RightInvalid) {
                data.egt1_right = change_egt_at_run_stage();
                isEgt1RightInvalid = true;
            }
            break;
        case 6: // 修改发动机转速传感器3
            if (!isRpm2LeftInvalid) {
                data.rpm2_left = change_rpm(); // 修改为此格式
                isRpm2LeftInvalid = true;
            }
            break;
        case 7: // 修改发动机转速传感器4
            if (!isRpm2RightInvalid) {
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm2RightInvalid = true;
            }
            break;
        case 8: // 修改EGT传感器3
            if (!isEgt2LeftInvalid) {
                data.egt2_left = change_egt_at_run_stage();
                isEgt2LeftInvalid = true;
            }
            break;
        case 9: // 修改EGT传感器4
            if (!isEgt2RightInvalid) {
                data.egt2_right = change_egt_at_run_stage();
                isEgt2RightInvalid = true;
            }
            break;
        case 10: // 一次性修改 rpm1_left 和 rpm1_right
            if (!isRpm1LeftInvalid && !isRpm1RightInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                data.rpm1_right = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
                isRpm1RightInvalid = true;
            }
            break;
        case 11: // 一次性修改 rpm2_left 和 rpm2_right
            if (!isRpm2LeftInvalid && !isRpm2RightInvalid) {
                data.rpm2_left = change_rpm(); // 修改为此格式
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm2LeftInvalid = true;
                isRpm2RightInvalid = true;
            }
            break;
        case 12: // 一次性修改 egt1_left 和 egt1_right
            if (!isEgt1LeftInvalid && !isEgt1RightInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                data.egt1_right = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
                isEgt1RightInvalid = true;
            }
            break;
        case 13: // 一次性修改 egt2_left 和 egt2_right
            if (!isEgt2LeftInvalid && !isEgt2RightInvalid) {
                data.egt2_left = change_egt_at_run_stage();
                data.egt2_right = change_egt_at_run_stage();
                isEgt2LeftInvalid = true;
                isEgt2RightInvalid = true;
            }
            break;
        case 14: // 一次性修改 rpm1_left, rpm1_right, rpm2_left, rpm2_right
            if (!isRpm1LeftInvalid && !isRpm1RightInvalid && !isRpm2LeftInvalid && !isRpm2RightInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                data.rpm1_right = change_rpm(); // 修改为此格式
                data.rpm2_left = change_rpm(); // 修改为此格式
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
                isRpm1RightInvalid = true;
                isRpm2LeftInvalid = true;
                isRpm2RightInvalid = true;
            }
            break;
        case 15: // 一次性修改 egt1_left, egt1_right, egt2_left, egt2_right
            if (!isEgt1LeftInvalid && !isEgt1RightInvalid && !isEgt2LeftInvalid && !isEgt2RightInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                data.egt1_right = change_egt_at_run_stage();
                data.egt2_left = change_egt_at_run_stage();
                data.egt2_right = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
                isEgt1RightInvalid = true;
                isEgt2LeftInvalid = true;
                isEgt2RightInvalid = true;
            }
            break;
        }
    }

    if (currentState == RUNNING) {
        switch (randChoice) {
        case 0: // 修改燃油流速
            if (!isFuelConsumptionInvalid) {
                data.fuel_consumption = 51; // 随机选择无效值或超限值
                isFuelConsumptionInvalid = true;
            }
            break;
        case 1: // 修改燃油余量
            if (!isFuelQuantityInvalid) {
                data.fuel_quantity = (std::rand() % 2 == 0) ? -1 : 999; // 随机选择无效值或超限值
                isFuelQuantityInvalid = true;
            }
            break;
        case 2: // 修改发动机转速传感器1
            if (!isRpm1LeftInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
            }
            break;
        case 3: // 修改发动机转速传感器2
            if (!isRpm1RightInvalid) {
                data.rpm1_right = change_rpm(); // 修改为此格式
                isRpm1RightInvalid = true;
            }
            break;
        case 4: // 修改EGT传感器1
            if (!isEgt1LeftInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
            }
            break;
        case 5: // 修改EGT传感器2
            if (!isEgt1RightInvalid) {
                data.egt1_right = change_egt_at_run_stage();
                isEgt1RightInvalid = true;
            }
            break;
        case 6: // 修改发动机转速传感器3
            if (!isRpm2LeftInvalid) {
                data.rpm2_left = change_rpm(); // 修改为此格式
                isRpm2LeftInvalid = true;
            }
            break;
        case 7: // 修改发动机转速传感器4
            if (!isRpm2RightInvalid) {
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm2RightInvalid = true;
            }
            break;
        case 8: // 修改EGT传感器3
            if (!isEgt2LeftInvalid) {
                data.egt2_left = change_egt_at_run_stage();
                isEgt2LeftInvalid = true;
            }
            break;
        case 9: // 修改EGT传感器4
            if (!isEgt2RightInvalid) {
                data.egt2_right = change_egt_at_run_stage();
                isEgt2RightInvalid = true;
            }
            break;
        case 10: // 一次性修改 rpm1_left 和 rpm1_right
            if (!isRpm1LeftInvalid && !isRpm1RightInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                data.rpm1_right = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
                isRpm1RightInvalid = true;
            }
            break;
        case 11: // 一次性修改 rpm2_left 和 rpm2_right
            if (!isRpm2LeftInvalid && !isRpm2RightInvalid) {
                data.rpm2_left = change_rpm(); // 修改为此格式
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm2LeftInvalid = true;
                isRpm2RightInvalid = true;
            }
            break;
        case 12: // 一次性修改 egt1_left 和 egt1_right
            if (!isEgt1LeftInvalid && !isEgt1RightInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                data.egt1_right = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
                isEgt1RightInvalid = true;
            }
            break;
        case 13: // 一次性修改 egt2_left 和 egt2_right
            if (!isEgt2LeftInvalid && !isEgt2RightInvalid) {
                data.egt2_left = change_egt_at_run_stage();
                data.egt2_right = change_egt_at_run_stage();
                isEgt2LeftInvalid = true;
                isEgt2RightInvalid = true;
            }
            break;
        case 14: // 一次性修改 rpm1_left, rpm1_right, rpm2_left, rpm2_right
            if (!isRpm1LeftInvalid && !isRpm1RightInvalid && !isRpm2LeftInvalid && !isRpm2RightInvalid) {
                data.rpm1_left = change_rpm(); // 修改为此格式
                data.rpm1_right = change_rpm(); // 修改为此格式
                data.rpm2_left = change_rpm(); // 修改为此格式
                data.rpm2_right = change_rpm(); // 修改为此格式
                isRpm1LeftInvalid = true;
                isRpm1RightInvalid = true;
                isRpm2LeftInvalid = true;
                isRpm2RightInvalid = true;
            }
            break;
        case 15: // 一次性修改 egt1_left, egt1_right, egt2_left, egt2_right
            if (!isEgt1LeftInvalid && !isEgt1RightInvalid && !isEgt2LeftInvalid && !isEgt2RightInvalid) {
                data.egt1_left = change_egt_at_run_stage();
                data.egt1_right = change_egt_at_run_stage();
                data.egt2_left = change_egt_at_run_stage();
                data.egt2_right = change_egt_at_run_stage();
                isEgt1LeftInvalid = true;
                isEgt1RightInvalid = true;
                isEgt2LeftInvalid = true;
                isEgt2RightInvalid = true;
            }
            break;
        }
    }
}

// 函数：检查单个转速是否在合理范围
bool checkRPM(double rpm) {
    return (rpm >= minRPM && rpm <= maxRPM);
}

// 函数：检查单个EGT是否在合理范围
bool checkEGT(double egt) {
    return (egt >= minEGT && egt <= maxEGT);
}


// 检查异常
void checkAnomalies(const SensorData& data) {// 检查各类异常
    //红色警告+停车 
     //双发转速或EGT传感器故障（无效值）：发动机停车，红色警告
    if (!checkRPM(data.rpm1_left)&&!checkRPM(data.rpm1_right)&&!checkRPM(data.rpm2_left)&&!checkRPM(data.rpm2_right)) {
        ExceptionInfo ex = { NSFail, L"ALL RPM Sensors Failure - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ NSFail, elapsedTime });
        warning_color[15] = RED;
    }
    if ((!checkEGT(data.egt1_left)) && (!checkEGT(data.egt1_right)) && (!checkEGT(data.egt2_left)) && (!checkEGT(data.egt2_right))) {
        ExceptionInfo ex = { EGTSFail, L"ALL EGT Sensors Failure - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGTSFail, elapsedTime });
        warning_color[16] = RED;
    }

    //超转2：发动机转速 𝑁1>120%，红色警告，发动机停车
    if ((data.rpm1_left > maxRPMLevel2&& checkRPM(data.rpm1_left)) ) {
        ExceptionInfo ex = { OverSpd2, L"RPM Overrun Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd2, elapsedTime });
        warning_color[21] = RED;
        
    }
    if ((data.rpm1_right > maxRPMLevel2 && checkRPM(data.rpm1_right))) {
        ExceptionInfo ex = { OverSpd2, L"RPM Overrun Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd2, elapsedTime });
        warning_color[21] = RED;
       
    }
    if ((data.rpm2_left > maxRPMLevel2 && checkRPM(data.rpm2_left))) {
        ExceptionInfo ex = { OverSpd2, L"RPM Overrun Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd2, elapsedTime });
        warning_color[21] = RED;
        
    }
    if ((data.rpm1_right > maxRPMLevel2 && checkRPM(data.rpm1_right))) {
        ExceptionInfo ex = { OverSpd2, L"RPM Overrun Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
        currentState = STOPPING;
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd2, elapsedTime });
        warning_color[21] = RED;
       
    }
    //超温2：启动过程中，EGT温度𝑇>1000℃ ，红色警告，发动机停车
    if (currentState == STARTING) {
        if ((data.egt1_left > maxTempLevel2 && checkEGT(data.egt1_left))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[23] = RED;
            
        }
        if ((data.egt1_right > maxTempLevel2 && checkEGT(data.egt1_right))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[23] = RED;
           
        }
        if ((data.egt2_left > maxTempLevel2 && checkEGT(data.egt2_left))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[23] = RED;
           
        }
        if ((data.egt2_right > maxTempLevel2 && checkEGT(data.egt2_right))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 2 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[23] = RED;
           
        }
    }

    //超温4：稳态时，EGT温度 𝑇>1100℃ ，红色警告，发动机停车
    if (currentState == RUNNING) {
        if ((data.egt1_left > maxTempLevel4 && checkEGT(data.egt1_left))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 4 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[25] = RED;
      
        }
        if ((data.egt1_right > maxTempLevel4 && checkEGT(data.egt1_right))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 4 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[25] = RED;
           
        }
        if ((data.egt2_left > maxTempLevel4 && checkEGT(data.egt2_left))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 4 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[25] = RED;
         
        }
        if ((data.egt2_right > maxTempLevel4 && checkEGT(data.egt2_right))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 4 - Engine Stopping", RED_COLOR, elapsedTime };
            currentState = STOPPING;
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[25] = RED;
           
        }
    }
    
    //红色警告
   // 燃油余量故障（无效值）：传感器故障告警，红色警告
    if (data.fuel_quantity < 0 || data.fuel_quantity > maxFuelLevel) { 
        ExceptionInfo ex = { FuelSFail, L"Fuel Quantity Sensor Failure", RED_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ FuelSFail, elapsedTime });
        warning_color[18] = RED;
        fuel_quantity_error_emerged = true;
    }

    //琥珀色警告
    //单发转速传感器故障（无效值）：转速告警，其他正常工作，琥珀色警告
    if ((!checkRPM(data.rpm1_left) && !checkRPM(data.rpm1_right) && (checkRPM(data.rpm2_left) or checkRPM(data.rpm2_right)))) {
        ExceptionInfo ex = { N1Fail, L"Two RPM Sensors Failure", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N1Fail, elapsedTime });
        warning_color[11] = AMBER_COLOR;
        rpm1_left_error_emerged = true;
        rpm1_right_error_emerged = true;
    }
    if (((checkRPM(data.rpm1_left) or checkRPM(data.rpm1_right)) && !checkRPM(data.rpm2_left) && !checkRPM(data.rpm2_right))) {
        ExceptionInfo ex = { N2Fail, L"Two RPM Sensors Failure", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N2Fail, elapsedTime });
        warning_color[13] = AMBER_COLOR;
        rpm2_left_error_emerged = true;
        rpm2_right_error_emerged = true;
    }

    //单发EGT传感器故障（无效值）：EGT告警，其他正常工作，琥珀色警告
    if ((!checkEGT(data.egt1_left) && !checkEGT(data.egt1_right) && (checkEGT(data.egt2_left) or checkEGT(data.egt2_right)))) {
        ExceptionInfo ex = { EGT1Fail, L"Two EGT Sensors Failure", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT1Fail, elapsedTime });
        warning_color[12] = AMBER_COLOR;
        egt1_left_error_emerged = true;
        egt1_right_error_emerged = true;
    }
    if (((checkEGT(data.egt1_left) or checkEGT(data.egt1_right)) && !checkEGT(data.egt2_left) && !checkEGT(data.egt2_right))) {
        ExceptionInfo ex = { EGT2Fail, L"Two EGT Sensors Failure", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT2Fail, elapsedTime });
        warning_color[14] = AMBER_COLOR;
        egt2_left_error_emerged = true;
        egt2_right_error_emerged = true;
    }

    //燃油余量低于 1000，其他数据正常（除了停车和未启动）：燃油余量低告警，琥珀色警告
    if (data.fuel_quantity < minFuelLevel) {
        ExceptionInfo ex = { LowFuel, L"Fuel Quantity Low", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ LowFuel, elapsedTime });
        warning_color[17] = AMBER_COLOR;
        fuel_quantity_error_emerged = true;
    }
    // 燃油流速超过50单位每秒：燃油指示告警，琥珀色警告
    if (data.fuel_consumption > maxFuelFlow) {
        ExceptionInfo ex = { OverFF, L"Fuel Flow Exceeded", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverFF, elapsedTime });
        warning_color[19] = AMBER_COLOR;
        fuel_consumption_error_emerged = true;
    }
    //超转1：发动机转速 𝑁1 > 105% ，琥珀色警告
    if ((maxRPMLevel2>data.rpm1_left > maxRPMLevel1 && checkRPM(data.rpm1_left)) ) {
        ExceptionInfo ex = { OverSpd1, L"RPM Overrun Level 1", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd1, elapsedTime });
        warning_color[20] = AMBER_COLOR;
   
    }
    if ((maxRPMLevel2 > data.rpm1_right > maxRPMLevel1 && checkRPM(data.rpm1_right))) {
        ExceptionInfo ex = { OverSpd1, L"RPM Overrun Level 1", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd1, elapsedTime });
        warning_color[20] = AMBER_COLOR;
       
    }
    if ((maxRPMLevel2 > data.rpm2_left > maxRPMLevel1 && checkRPM(data.rpm2_left))) {
        ExceptionInfo ex = { OverSpd1, L"RPM Overrun Level 1", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd1, elapsedTime });
        warning_color[20] = AMBER_COLOR;
        
    }
    if ((maxRPMLevel2 > data.rpm2_right > maxRPMLevel1 && checkRPM(data.rpm1_right))) {
        ExceptionInfo ex = { OverSpd1, L"RPM Overrun Level 1", AMBER_COLOR, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ OverSpd1, elapsedTime });
        warning_color[20] = AMBER_COLOR;
        
    }
    //超温1：启动过程中，EGT温度 𝑇 > 850℃ ，琥珀色警告
    if (currentState == STARTING) {
        if ((maxTempLevel2>data.egt1_left > maxTempLevel1 && checkEGT(data.egt1_left))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 1", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[22] = AMBER_COLOR;
           
        }
        if ((maxTempLevel2 > data.egt1_right > maxTempLevel1 && checkEGT(data.egt1_right))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 1", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[22] = AMBER_COLOR;
        }
        if ((maxTempLevel2 > data.egt2_left > maxTempLevel1 && checkEGT(data.egt2_left))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 1", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[22] = AMBER_COLOR;
        
        }
        if ((maxTempLevel2 > data.egt2_right > maxTempLevel1 && checkEGT(data.egt2_right))) {
            ExceptionInfo ex = { OverTemp2, L"EGT Overtemperature Level 1", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp2, elapsedTime });
            warning_color[22] = AMBER_COLOR;
         
        }
    }
    //超温3：稳态时，EGT温度 𝑇>950℃ ，琥珀色警告
    if (currentState == RUNNING) {
        if ((maxTempLevel4>data.egt1_left > maxTempLevel3 && checkEGT(data.egt1_left))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 3", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[24] = AMBER_COLOR;
          
        }
        if ((maxTempLevel4 > data.egt1_right > maxTempLevel3 && checkEGT(data.egt1_right))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 3", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[24] = AMBER_COLOR;
          
        }
        if ((maxTempLevel4 > data.egt2_left > maxTempLevel3 && checkEGT(data.egt2_left))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 3", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[24] = AMBER_COLOR;
          
        }
        if ((maxTempLevel4 > data.egt2_right > maxTempLevel3 && checkEGT(data.egt2_right))) {
            ExceptionInfo ex = { OverTemp4, L"EGT Overtemperature Level 3", AMBER_COLOR, elapsedTime };
            activeExceptions.push_back(ex);
            logAnomaly(ex);
            exceptionLastLoggedTime.insert({ OverTemp4, elapsedTime });
            warning_color[24] = AMBER_COLOR;
          
        }
    }

    //白色警告
     // N1LFail, N1RFail, N2LFail, N2RFail (单个RPM传感器故障)
    if (!checkRPM(data.rpm1_left)&& checkRPM(data.rpm1_right)) {
        ExceptionInfo ex = { N1LFail, L"Single RPM Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N1LFail, elapsedTime });
        warning_color[3] = WHITE;
        rpm1_left_error_emerged = true;
    }
    if (checkRPM(data.rpm1_left) && !checkRPM(data.rpm1_right)) {
        ExceptionInfo ex = { N1RFail, L"Single RPM Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N1RFail, elapsedTime });
        warning_color[4] = WHITE;
        rpm1_right_error_emerged = true;
    }
    if (!checkRPM(data.rpm2_left) && checkRPM(data.rpm2_right)) {
        ExceptionInfo ex = { N2LFail, L"Single RPM Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N2LFail, elapsedTime });
        warning_color[7] = WHITE;
        rpm2_left_error_emerged = true;
    }
    if (checkRPM(data.rpm2_left) && !checkRPM(data.rpm2_right)) {
        ExceptionInfo ex = { N2RFail, L"Single RPM Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ N2RFail, elapsedTime });
        warning_color[8] = WHITE;
        rpm2_right_error_emerged = true;
    }

    // EGT1LFail, EGT1RFail, EGT2LFail, EGT2RFail (单个EGT传感器故障)
    if (!checkEGT(data.egt1_left)&&checkEGT(data.egt1_right)) {
        ExceptionInfo ex = { EGT1LFail, L"Single EGT Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT1LFail, elapsedTime });
        warning_color[5] = WHITE;
        egt1_left_error_emerged = true;
    }
    if (checkEGT(data.egt1_left) && !checkEGT(data.egt1_right)) {
        ExceptionInfo ex = { EGT1RFail, L"Single EGT Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT1RFail, elapsedTime });
        warning_color[6] = WHITE;
        egt1_right_error_emerged = true;
    }
    if (!checkEGT(data.egt2_left) && checkEGT(data.egt2_right)) {
        ExceptionInfo ex = { EGT2LFail, L"Single EGT Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT2LFail, elapsedTime });
        warning_color[9] = WHITE;
        egt2_left_error_emerged = true;
    }
    if (checkEGT(data.egt2_left) && !checkEGT(data.egt2_right)) {
        ExceptionInfo ex = { EGT2RFail, L"Single EGT Sensor Failure", WHITE, elapsedTime };
        activeExceptions.push_back(ex);
        logAnomaly(ex);
        exceptionLastLoggedTime.insert({ EGT2RFail, elapsedTime });
        warning_color[10] = WHITE;
        egt2_right_error_emerged = true;
    }
    removeDuplicateExceptions();
    sortExceptions();
}

// 清理过期异常
void cleanupExceptions() {
    // 移除已显示超过5秒的异常
    activeExceptions.erase(
        std::remove_if(activeExceptions.begin(), activeExceptions.end(),
            [=](const ExceptionInfo& ex) -> bool {
                return (elapsedTime - ex.triggerTime) > 5.0;
            }),
        activeExceptions.end()
    );
}

// 删除 activeExceptions 中重复的异常类型
void removeDuplicateExceptions() {
    std::map<ExceptionType, int> exceptionCount;

    // 统计每种异常类型的出现次数
    for (const auto& ex : activeExceptions) {
        exceptionCount[ex.type]++;
    }

    // 遍历 activeExceptions，保留每种类型的第一个出现的异常
    std::vector<ExceptionInfo> uniqueExceptions;
    for (const auto& ex : activeExceptions) {
        if (exceptionCount[ex.type] > 0) {
            uniqueExceptions.push_back(ex);
            exceptionCount[ex.type] = 0;  // 确保每种类型只保留一个
        }
    }

    // 更新 activeExceptions，保留去重后的异常
    activeExceptions = uniqueExceptions;
}

// 依据 color 和 triggerTime 对异常信息进行排序
void sortExceptions() {
    std::sort(activeExceptions.begin(), activeExceptions.end(), [](const ExceptionInfo& ex1, const ExceptionInfo& ex2) {
        // 首先按照 color 排序，颜色较小的排前面
        if (ex1.color != ex2.color) {
            return ex1.color < ex2.color;
        }
        // 如果 color 相同，则按照 triggerTime 排序，时间较早的排前面
        return ex1.triggerTime < ex2.triggerTime;
        });
}

template <typename T>
T clamp(T value, T minVal, T maxVal) {
    if (value < minVal) return minVal;
    if (value > maxVal) return maxVal;
    return value;
}

// 添加随机扰动
double add_random_noise(double value, double range) {
    if (value <= 0) {
        return 0;  // 无效输入直接返回 0
    }

    // 初始化随机种子（仅需一次）
    static bool isSeeded = false;
    if (!isSeeded) {
        std::srand(static_cast<unsigned>(std::time(0)));
        isSeeded = true;
    }

    // 波动参数
    double amplitude = range / value; // 振幅比例
    double noiseLevel = 0.005;        // 随机噪声比例
    double frequency = 1.0;           // 固定波动频率
    static double time = 0;           // 模拟时间步长

    // 平滑波动
    double fluctuation = value * (1 + amplitude * std::sin(2 * M_PI * frequency * time));

    // 随机扰动
    double noise = value * ((std::rand() / static_cast<double>(RAND_MAX)) * 2 * noiseLevel - noiseLevel);

    // 结果计算
    double result = fluctuation + noise;

    // 限制结果范围
    double minValue = value * (1 - amplitude);
    double maxValue = value * (1 + amplitude);
    result = clamp(result, minValue, maxValue);

    // 更新时间步长
    time += 0.005;

    return result;
}


void updateRPM(double& rpm, double base, double deltaTime) {
    if (rpm > 10000) {
        rpm *= pow(base, deltaTime);
    }
    else {
        rpm -= 5000 * deltaTime;
    }
}

void updateEGT(double& egt, double base, double deltaTime) {
    if (egt > 300) {
        egt *= pow(base, deltaTime);
    }
    else if(egt>20){
        egt -= 150 * deltaTime;
    }
    else {
        egt = 20;
    }
}

int main() {
    srand(static_cast<unsigned>(time(0))); // 初始化随机种子

    // 初始化窗口
    initgraph(WINDOW_WIDTH, WINDOW_HEIGHT);
    setbkcolor(TRANSPARENT);
    cleardevice();

    // 初始化按钮
    initializeButtons();
    drawButton(startButton);
    drawButton(stopButton);
    drawButton(increaseThrustButton);
    drawButton(decreaseThrustButton);
    drawButton(createErrorButton);
    // 打开CSV文件
    dataFile.open("sensor_data.csv");
    if (!dataFile.is_open()) {
        closegraph();
        return -1;
    }
    dataFile << "Time,1LeftRPM,1RightRPM,1LeftEGT,1RightEGT,2LeftRPM,2RightRPM,2LeftEGT,2RightEGT，FuelFlow,FuelQuantity\n";

    // 打开日志文件
    logFile.open("anomalies.log");
    if (!logFile.is_open()) {
        dataFile.close();
        closegraph();
        return -1;
    }

    // 初始化传感器数据
    data.rpm1_left = 0.0;
    data.rpm1_right = 0.0;
    data.egt1_left = 20.0;
    data.egt1_right = 20.0;
    data.rpm2_left = 0.0;
    data.rpm2_right = 0.0;
    data.egt2_left = 20.0;
    data.egt2_right = 20.0;
    data.fuel_quantity = 20000.0;
    data.fuel_consumption = 0.0;

    // 主循环
    bool running = true;
    while (running) {
        // 处理键盘事件（ESC退出）
        if (_kbhit()) {  // 使用 _kbhit 代替 kbhit
            int key = _getch();  // 使用 _getch 代替 getch
            if (key == 27) { // ESC键
                running = false;
            }
        }

        // 处理鼠标点击
        if (MouseHit()) {
            MOUSEMSG msg = GetMouseMsg(); // 使用 MOUSEMSG
            if (msg.uMsg == WM_LBUTTONDOWN) { // 检查鼠标消息
                int mx = msg.x;
                int my = msg.y;
                if (isButtonClicked(startButton, mx, my)) {
                    if (currentState == OFF || currentState == STOPPING) {
                        currentState = STARTING;
                        elapsedTime = 0.0;
                        BeginBatchDraw();
                        cleardevice();
                        // 重新绘制按钮
                        drawButton(startButton);
                        drawButton(stopButton);
                        drawButton(increaseThrustButton);
                        drawButton(decreaseThrustButton);
                        drawButton(createErrorButton);
                    }
                }
                if (isButtonClicked(stopButton, mx, my)) {

                    if (currentState == RUNNING || currentState == STARTING) {
                        currentState = STOPPING;
                        elapsedTime = 0.0;
                        BeginBatchDraw();
                        cleardevice();
                        // 重新绘制按钮
                        drawButton(startButton);
                        drawButton(stopButton);
                        drawButton(increaseThrustButton);
                        drawButton(decreaseThrustButton);
                        drawButton(createErrorButton);
                    }
                }
                if (isButtonClicked(createErrorButton,mx,my)) {
                    simulateExceptions();
                    drawButton(startButton);
                    drawButton(stopButton);
                    drawButton(increaseThrustButton);
                    drawButton(decreaseThrustButton);
                    drawButton(createErrorButton);
                }
                if (isButtonClicked(increaseThrustButton, mx, my)) {
                    if (currentState == RUNNING) {
                        data.fuel_consumption += 1.0; // 增加1单位每秒
                        // 随机增加3%到5%
                        double randomFactor = 1.0 + ((rand() % 3 + 3) / 100.0); // 1.03到1.05
                        data.fuel_consumption ++;
                        data.rpm1_left *= randomFactor;
                        data.rpm1_right *= randomFactor;
                        data.rpm2_left *= randomFactor;
                        data.rpm2_right *= randomFactor;
                        data.egt1_left *= randomFactor;
                        data.egt1_right *= randomFactor;
                        data.egt2_left *= randomFactor;
                        data.egt2_right *= randomFactor;
                        // 确保 fuelFlow 不超过50
                        if (data.fuel_consumption > 50.0)
                            data.fuel_consumption = 50.0;
                    }
                }
                if (isButtonClicked(decreaseThrustButton, mx, my)) {
                    if (currentState == RUNNING && data.fuel_consumption > 0.0) {
                        data.fuel_consumption -= 1.0; // 减少1单位每秒
                        // 随机减少3%到5%
                        double randomFactor = 1.0 - ((rand() % 3 + 3) / 100.0); // 0.97到0.95
                        data.fuel_consumption++;
                        data.rpm1_left *= randomFactor;
                        data.rpm1_right *= randomFactor;
                        data.rpm2_left *= randomFactor;
                        data.rpm2_right *= randomFactor;
                        data.egt1_left *= randomFactor;
                        data.egt1_right *= randomFactor;
                        data.egt2_left *= randomFactor;
                        data.egt2_right *= randomFactor;
                        // 确保 fuelFlow 不低于0
                        if (data.fuel_consumption < 0.0)
                            data.fuel_consumption = 0.0;
                    }
                }
            }
        }
        // 检测并处理异常
        checkAnomalies(data);
        // 数据生成逻辑
        switch (currentState) {
        case OFF:
            // 不生成数据
            break;
        case STARTING:
            warning_color[0] = GREEN;
            warning_color[1] = BLACK;
            warning_color[2] = BLACK;
            if (elapsedTime <= 2.0) { // 前2秒线性增加
                if(checkRPM(data.rpm1_left))
                {
                    data.rpm1_left += (10000.0 / 1.0) * deltaTime; // 每秒10^4转                   
                    data.rpm1_left = add_random_noise(data.rpm1_left, data.rpm1_left * 0.005);
                   
                }
                if(checkRPM(data.rpm1_right))
                {
                    data.rpm1_right += (10000.0 / 1.0) * deltaTime; // 每秒10^4转                   
                    data.rpm1_right = add_random_noise(data.rpm1_right, data.rpm1_right * 0.005);
                }

                if (checkRPM(data.rpm2_left))
                {
                    data.rpm2_left += (10000.0 / 1.0) * deltaTime; // 每秒10^4转                   
                    data.rpm2_left = add_random_noise(data.rpm2_left, data.rpm2_left * 0.005);
                }

                if (checkRPM(data.rpm2_right))
                {
                    data.rpm2_right += (10000.0 / 1.0) * deltaTime; // 每秒10^4转                   
                    data.rpm2_right = add_random_noise(data.rpm2_right, data.rpm2_right * 0.005);
                }
                if(data.fuel_consumption>=0&& data.fuel_consumption<=50)
                {
                    data.fuel_consumption += 5.0 * deltaTime; // 每秒5单位
                    data.fuel_consumption = add_random_noise(data.fuel_consumption, data.fuel_consumption * 0.005);
                }
            }
            else { // 对数增加，直到95%额定转速
                double t = elapsedTime - 2.0;
                if (t > 0) {
                    if (checkRPM(data.rpm1_left))
                    {
                        data.rpm1_left = 23000.0 * log10(t + 1) + 20000.0;
                        data.rpm1_left = add_random_noise(data.rpm1_left, data.rpm1_left * 0.005);
                    }

                    if (checkRPM(data.rpm1_right))
                    {
                        data.rpm1_right = 23000.0 * log10(t + 1) + 20000.0;
                        data.rpm1_right = add_random_noise(data.rpm1_right, data.rpm1_right * 0.005);
                    }

                    if (checkRPM(data.rpm2_left))
                    {
                        data.rpm2_left = 23000.0 * log10(t + 1) + 20000.0;
                        data.rpm2_left = add_random_noise(data.rpm2_left, data.rpm2_left * 0.005);
                    }

                    if (checkRPM(data.rpm2_right))
                    {
                        data.rpm2_right = 23000.0 * log10(t + 1) + 20000.0;
                        data.rpm2_right = add_random_noise(data.rpm2_right, data.rpm2_right * 0.005);
                    }

                    if (checkEGT(data.egt1_left))
                    {
                        data.egt1_left = 900.0 * log10(t + 1) + 20.0;
                        data.egt1_left = add_random_noise(data.egt1_left, data.egt1_left * 0.005);
                    }

                    if (checkEGT(data.egt1_right))
                    {
                        data.egt1_right = 900.0 * log10(t + 1) + 20.0;
                        data.egt1_right = add_random_noise(data.egt1_right, data.egt1_right * 0.005);
                    }

                    if (checkEGT(data.egt2_left))
                    {
                        data.egt2_left = 900.0 * log10(t + 1) + 20.0;
                        data.egt2_left = add_random_noise(data.egt2_left, data.egt2_left * 0.005);
                    }

                    if (checkEGT(data.egt2_right))
                    {
                        data.egt2_right = 900.0 * log10(t + 1) + 20.0;
                        data.egt2_right = add_random_noise(data.egt2_right, data.egt2_right * 0.005);
                    }
                   
                    if (data.fuel_consumption >= 0 && data.fuel_consumption <= 50)
                    {
                        data.fuel_consumption = 42.0 * log10(t + 1) + 10.0;
                        data.fuel_consumption = add_random_noise(data.fuel_consumption, data.fuel_consumption * 0.005);
                    }

                    // 检查是否达到95%额定转速（95%）
                    double rpmThreshold = 0.95; // 95%
                    if (min(data.rpm1_left, data.rpm1_right, data.rpm2_left, data.rpm2_right) >= rpmThreshold* ENGINE_RATED_RPM) {
                        currentState = RUNNING;
                    }
                }
            }
            break;
        case RUNNING:
            warning_color[0] = BLACK;
            warning_color[2] = BLACK;
            if((data.rpm1_left+ data.rpm1_right + data.rpm2_left + data.rpm2_right)/4>38000)
            {
                warning_color[1] = GREEN;
            }
            else {
                warning_color[1] = BLACK;
            }
            if (checkRPM(data.rpm1_left))
            {
                data.rpm1_left = add_random_noise(data.rpm1_left, data.rpm1_left * 0.001);
                data.rpm1_left = (std::max)(0.0, (std::min)(data.rpm1_left, 50000.0));
            }

            if (checkRPM(data.rpm1_right))
            {
                data.rpm1_right = add_random_noise(data.rpm1_right, data.rpm1_right * 0.001);
                data.rpm1_right = (std::max)(0.0, (std::min)(data.rpm1_right, 50000.0));
            }

            if (checkRPM(data.rpm2_left))
            {
                data.rpm2_left = add_random_noise(data.rpm2_left, data.rpm2_left * 0.001);
                data.rpm2_left = (std::max)(0.0, (std::min)(data.rpm2_left, 50000.0));
            }

            if (checkRPM(data.rpm2_right))
            {
                data.rpm2_right = add_random_noise(data.rpm2_right, data.rpm2_right * 0.001);
                data.rpm2_right = (std::max)(0.0, (std::min)(data.rpm2_right, 50000.0));
            }

            if (checkEGT(data.egt1_left))
            {
                data.egt1_left = add_random_noise(data.egt1_left, data.egt1_left * 0.001);
                data.egt1_left = (std::max)(0.0, (std::min)(data.egt1_left, 1200.0));
            }

            if (checkEGT(data.egt1_right))
            {
                data.egt1_right = add_random_noise(data.egt1_right, data.egt1_right * 0.001);
                data.egt1_right = (std::max)(0.0, (std::min)(data.egt1_right, 1200.0));
            }

            if (checkEGT(data.egt2_left))
            {
                data.egt2_left = add_random_noise(data.egt2_left, data.egt2_left * 0.001);
                data.egt2_left = (std::max)(0.0, (std::min)(data.egt2_left, 1200.0));
            }

            if (checkEGT(data.egt2_right))
            {
                data.egt2_right = add_random_noise(data.egt2_right, data.egt2_right * 0.001);
                data.egt2_right = (std::max)(0.0, (std::min)(data.egt2_right, 1200.0));
            }

            if (data.fuel_consumption >= 0 && data.fuel_consumption <= 50)
            {
                data.fuel_consumption = add_random_noise(data.fuel_consumption, data.fuel_consumption * 0.001);
                data.fuel_consumption = (std::max)(0.0, (std::min)(data.fuel_consumption, 50.0));
            }
            

            
            break;
        case STOPPING:
            warning_color[0] = BLACK;
            warning_color[1] = BLACK;
            warning_color[2] = RED;
            if (errorTime <= 10.0) { // 10秒内对数下降
                double base = 0.75; // 0 < base < 1
                updateRPM(data.rpm1_left, base, deltaTime);
                updateRPM(data.rpm1_right, base, deltaTime);
                updateRPM(data.rpm2_left, base, deltaTime);
                updateRPM(data.rpm2_right, base, deltaTime);

                updateEGT(data.egt1_left, base, deltaTime);
                updateEGT(data.egt1_right, base, deltaTime);
                updateEGT(data.egt2_left, base, deltaTime);
                updateEGT(data.egt2_right, base, deltaTime);
                data.fuel_consumption = 0.0;
            }
            else { // 停止
                currentState = OFF;
            }
            errorTime += deltaTime;
            break;
        }

        // 燃油余量减少
       if(!fuel_quantity_error_emerged&&!fuel_consumption_error_emerged)
       {
           data.fuel_quantity -= data.fuel_consumption * deltaTime;
           if(data.fuel_quantity<0.0)data.fuel_quantity = 0.0;
       }

            if(!rpm1_left_error_emerged)
            {
                data.rpm1_left = (std::max)(0.0, (std::min)(data.rpm1_left, 50000.0));
            }
            if (!rpm1_right_error_emerged)
            {
                data.rpm1_right = (std::max)(0.0, (std::min)(data.rpm1_right, 50000.0));
            }
            if (!rpm2_left_error_emerged)
            {
                data.rpm2_left = (std::max)(0.0, (std::min)(data.rpm2_left, 50000.0));
            }
            if (!rpm2_right_error_emerged)
            {
                data.rpm2_right = (std::max)(0.0, (std::min)(data.rpm2_right, 50000.0));
            }
            if (!egt1_left_error_emerged)
            {
                data.egt1_left = (std::max)(20.0, (std::min)(data.egt1_left, 1200.0));
            }
            if (!egt1_right_error_emerged)
            {
                data.egt1_right = (std::max)(20.0, (std::min)(data.egt1_right, 1200.0));
            }
            if (!egt2_left_error_emerged)
            {
                data.egt2_left = (std::max)(20.0, (std::min)(data.egt2_left, 1200.0));
            }
            if (!egt2_right_error_emerged)
            {
                data.egt2_right = (std::max)(20.0, (std::min)(data.egt2_right, 1200.0));
            }
            
            if (!fuel_consumption_error_emerged)
            {
                data.fuel_consumption = (std::max)(0.0, (std::min)(data.fuel_consumption, 50.0));
            }

        // 清理过期异常
        cleanupExceptions();

        // 绘制界面
        BeginBatchDraw();
        cleardevice();
        // 绘制按钮
        drawButton(startButton);
        drawButton(stopButton);
        drawButton(increaseThrustButton);
        drawButton(decreaseThrustButton);
        drawButton(createErrorButton);
        // 绘制仪表盘
        // 根据传感器状态调整颜色
        COLORREF rpm1_left_color = (data.rpm1_left > 48000) ? RED_COLOR :
            (data.rpm1_left > 42000) ? AMBER_COLOR : WHITE;

        COLORREF rpm1_right_color = (data.rpm1_right > 48000) ? RED_COLOR :
            (data.rpm1_right > 42000) ? AMBER_COLOR : WHITE;

        COLORREF rpm2_left_color = (data.rpm2_left > 48000) ? RED_COLOR :
            (data.rpm2_left > 42000) ? AMBER_COLOR : WHITE;

        COLORREF rpm2_right_color = (data.rpm2_right > 48000) ? RED_COLOR :
            (data.rpm2_right > 42000) ? AMBER_COLOR : WHITE;
        // 设定颜色：根据 EGT（排气温度）值设置不同的颜色
        COLORREF egt1_left_color = WHITE; 
        COLORREF egt1_right_color = WHITE;
        COLORREF egt2_left_color = WHITE;
        COLORREF egt2_right_color = WHITE;
        
            
             
        if(currentState==STARTING)
        {
             egt1_left_color = (data.egt1_left > 1000.0) ? RED_COLOR :
                (data.egt1_left > 850.0) ? AMBER_COLOR : WHITE;

             egt1_right_color = (data.egt1_right > 1000.0) ? RED_COLOR :
                (data.egt1_right > 850.0) ? AMBER_COLOR : WHITE;

             egt2_left_color = (data.egt2_left > 1000.0) ? RED_COLOR :
                (data.egt2_left > 850.0) ? AMBER_COLOR : WHITE;

             egt2_right_color = (data.egt2_right > 1000.0) ? RED_COLOR :
                (data.egt2_right > 850.0) ? AMBER_COLOR : WHITE;
        }
        if (currentState == RUNNING)
        {
            egt1_left_color = (data.egt1_left > 1100.0) ? RED_COLOR :
                (data.egt1_left > 950.0) ? AMBER_COLOR : WHITE;

            egt1_right_color = (data.egt1_right > 1100.0) ? RED_COLOR :
                (data.egt1_right > 950.0) ? AMBER_COLOR : WHITE;

            egt2_left_color = (data.egt2_left > 1100.0) ? RED_COLOR :
                (data.egt2_left > 950.0) ? AMBER_COLOR : WHITE;

            egt2_right_color = (data.egt2_right > 1100.0) ? RED_COLOR :
                (data.egt2_right > 950.0) ? AMBER_COLOR : WHITE;
        }
        drawDial(80, 80, data.rpm1_left, ENGINE_RATED_RPM, L"N1L", rpm1_left_color, true);
        drawDial(230, 80, data.rpm1_right, ENGINE_RATED_RPM, L"N1R", rpm1_right_color, true);
        drawDial(80, 220, data.egt1_left, ENGINE_RATED_TEMP, L"EGT1L", egt1_left_color, false);
        drawDial(230, 220, data.egt1_right, ENGINE_RATED_TEMP,L"EGT1R", egt1_right_color, false);
        drawDial(80, 360, data.rpm2_left, ENGINE_RATED_RPM, L"N2L", rpm2_left_color, true);
        drawDial(230, 360, data.rpm2_right, ENGINE_RATED_RPM, L"N2R", rpm2_right_color, true);
        drawDial(80, 500, data.egt2_left, ENGINE_RATED_TEMP,L"EGT2L", egt2_left_color, false);
        drawDial(230, 500, data.egt2_right, ENGINE_RATED_TEMP, L"EGT2R", egt2_right_color, false);
        // 绘制燃油流速
        drawFuelFlow(data.fuel_consumption,data.fuel_quantity);

        // 绘制状态显示
        std::wstring status;
        switch (currentState) {
        case OFF:
            status = L"Status: OFF";
            break;
        case STARTING:
            status = L"Status: STARTING";
            break;
        case RUNNING:
            status = L"Status: RUNNING";
            break;
        case STOPPING:
            status = L"Status: STOPPING";
            break;
        }
        drawStatus(800, 50, status);

        // 绘制异常警示
        drawAlerts();

        // 记录数据
        logData(data);

        // 更新时间
        elapsedTime += deltaTime;

        // 更新图形显示（双缓冲）
        FlushBatchDraw();//这里也可以用EndBatchDraw();

        // 延时
        SleepMicroseconds(3000);
    }

    // 关闭文件
    dataFile.close();
    logFile.close();

    closegraph();
    return 0;
}